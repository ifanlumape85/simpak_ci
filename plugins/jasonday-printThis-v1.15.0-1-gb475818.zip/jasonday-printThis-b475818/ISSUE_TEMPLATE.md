Description of issue:


====================================================================

Code & options:
```
//Example:
$('#myDiv').printThis({
   importCSS: false
});
 ```



